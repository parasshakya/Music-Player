package com.paras.musicplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
